package hr.java.production.model;

import java.math.BigDecimal;

public class Fruit extends Item implements Edible{
    BigDecimal weight;
    public Fruit(String name, Category category, BigDecimal width, BigDecimal height, BigDecimal length, BigDecimal productionCost, BigDecimal sellingPrice, BigDecimal weight) {
        super(name, category, width, height, length, productionCost, sellingPrice);
        this.weight = weight;
    }

    @Override
    public Integer calculateCalories() {
        BigDecimal result =  weight.multiply(BigDecimal.valueOf(CALORIES_PER_KG));
        return result.intValue();
    }

    @Override
    public BigDecimal calculatePrice() {
        return weight.divide(getSellingPrice());
    }
}
