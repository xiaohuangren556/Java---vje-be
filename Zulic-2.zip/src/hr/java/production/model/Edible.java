package hr.java.production.model;

import java.math.BigDecimal;

public interface Edible {
    Integer calculateCalories();
    BigDecimal calculatePrice();
    static final Integer CALORIES_PER_KG = 4;
}
