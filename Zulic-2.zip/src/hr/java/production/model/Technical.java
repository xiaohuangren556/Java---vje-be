package hr.java.production.model;

import java.time.LocalDate;
import java.util.Scanner;

public sealed interface Technical permits Laptop {
    Integer warrantyDuration();
}
