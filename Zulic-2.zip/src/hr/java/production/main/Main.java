package hr.java.production.main;

import hr.java.production.model.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
            Scanner scanner = new Scanner(System.in);
            Category[] categories = new Category[3];
            Boolean checker = false;
            Category categoryToCompare = null;
            for(int i = 0; i < 3; i++){
                do{
                    categoryToCompare = getCategory(scanner);
                    if(i >= 1){
                        checker = checkIdenticalCategories(categoryToCompare, categories);
                    }
                    if(checker){
                        System.out.println("You've entered identical categories. Please, repeat input.");
                    }
                }while(checker);
                categories[i] = categoryToCompare;
            }

            checker = false;
            Item[] items= new Item[3];
            Item itemToCompare = null;

            for(int i = 0; i < 3; i++){
                do{
                    itemToCompare = getItem(scanner);
                    if(i >= 1){
                        checker = checkIdenticalItems(itemToCompare, items);
                    }
                    if(checker){
                        System.out.println("You've entered identical items. Please, repeat input.");
                    }
                }while(checker);
                items[i] = itemToCompare;
            }

            checker = false;
            Factory[] factories = new Factory[2];
            Factory factoryToCompare = null;
            for(int i = 0; i < 2; i++){
                do{
                    factoryToCompare = getFactory(scanner);
                    if(i >= 1){
                        checker = checkIdenticalFactories(factoryToCompare, factories);
                    }
                    if(checker){
                        System.out.println("You've entered identical factories. Please, repeat input.");
                    }
                }while(checker);
                factories[i] = getFactory(scanner);
            }

            Factory withBiggestVolume = getBiggestVolume(factories);

            checker = false;
            Store[] stores = new Store[2];
            Store storeToCompare = null;
            for(int i = 0; i < 2; i++){
                do{
                    storeToCompare = getStore(scanner);
                    if(i >= 1){
                        checker = checkIdenticalStores(storeToCompare, stores);
                    }
                    if(checker){
                        System.out.println("You've entered identical stores. Please, repeat input.");
                    }
                }while(checker);
                stores[i] = storeToCompare;
            }

            Store withCheapestItem = getStoreWithCheapestItem(stores);
            Item itemwithMostCalories = getItemWithBiggestCal(items);
            Item itemwithBiggestPrice = getItemWithBiggestPrice(items, scanner);
            printBiggestPriceAndCalories(itemwithMostCalories, itemwithBiggestPrice);
            printShortestwarranty(items);
        }

        private static Category getCategory(Scanner iscanner){
               System.out.println("Enter the name of the category");
               String name = iscanner.nextLine();
               System.out.println("Enter the description of the category");
               String description = iscanner.nextLine();
               Category novaKat = new Category(name, description);
               return novaKat;
        }

        private static Item getItem(Scanner iScanner){
            Item noviArt = null;
            System.out.println("Is the item edible? Input Yes or No");
            String isEdible = iScanner.nextLine();
            Integer typeOfEdible = null;
            BigDecimal weight = null;
            if(isEdible.equals("Yes")){
                System.out.println("Please choose if it's meat or fruit. 1 - meat, 2 - fruit");
                typeOfEdible = iScanner.nextInt();
                iScanner.nextLine();
                System.out.println("Please enter wight of item.");
                weight = iScanner.nextBigDecimal();
                iScanner.nextLine();
            }
            String isLaptop = null;
            if(isEdible.equals("No")){
                System.out.println("Is the item a laptop? Input Y or N");
                isLaptop = iScanner.nextLine();
            }
            System.out.println("Enter the name of the item");
            String name = iScanner.nextLine();
            System.out.println("Enter the category of the item");
            Category category = null;
            if(isEdible.equals("Yes")){
                if(typeOfEdible == Item.ITEM_TYPE_MEAT){
                    category.getName().equals("Meat");
                    category.getDescription().equals("Meat product");
                }
                else{
                    category.getName().equals("Fruit");
                    category.getDescription().equals("Fruit product");
                }
            }
            else if(isLaptop == Item.ITEM_TYPE_LAPTOP){
                category.getName().equals("Computers");
                category.getDescription().equals("Laptops");
            }
            else
                category = getCategory(iScanner);
            System.out.println("Enter the width of the item");
            BigDecimal width = iScanner.nextBigDecimal();
            iScanner.nextLine();
            System.out.println("Enter the height of the item");
            BigDecimal height = iScanner.nextBigDecimal();
            iScanner.nextLine();
            System.out.println("Enter the length of the item");
            BigDecimal length = iScanner.nextBigDecimal();
            iScanner.nextLine();
            System.out.println("Enter the production cost of the item");
            BigDecimal productionCost = iScanner.nextBigDecimal();
            iScanner.nextLine();
            System.out.println("Enter the selling price of the item");
            BigDecimal sellingPrice = iScanner.nextBigDecimal();
            iScanner.nextLine();
            if(typeOfEdible == Item.ITEM_TYPE_MEAT)
                noviArt = new Meat(name, category, width, height, length, productionCost, sellingPrice, weight);

            else if(typeOfEdible == Item.ITEM_TYPE_FRUIT)
                noviArt = new Fruit(name, category, width, height, length, productionCost, sellingPrice, weight);

            else if(isLaptop == Item.ITEM_TYPE_LAPTOP){
                System.out.println("Enter warranty period in months: ");
                Integer warrantyMonths = iScanner.nextInt();
                iScanner.nextLine();
                noviArt = new Laptop(name, category, width, height, length, productionCost, sellingPrice, warrantyMonths);
            }
            else
                noviArt = new Item(name, category, width, height, length, productionCost, sellingPrice);
            return noviArt;
        }

        private static Address getAddress(Scanner iScanner){
            System.out.println("Enter the name of the name of the street");
            String street = iScanner.nextLine();
            System.out.println("Enter the house number");
            String houseNumber = iScanner.nextLine();
            System.out.println("Enter the name of the city");
            String city = iScanner.nextLine();
            System.out.println("Enter the postal code of the city");
            String postalCode = iScanner.nextLine();
            Address tempAddress = new Address.Builder()
                    .street(street)
                    .houseNumber(houseNumber)
                    .city(city)
                    .postalCode(postalCode)
                    .build();
            return tempAddress;
        }
        private static Factory getFactory(Scanner iScanner){
            System.out.println("Enter the name of the factory");
            String name = iScanner.nextLine();
            System.out.println("Enter the address of the factory");
            Address address = getAddress(iScanner);
            System.out.println("Enter the number of items:");
            int numberOfItems = iScanner.nextInt();
            iScanner.nextLine();
            Item[] items = new Item[numberOfItems];
            Item itemToCheck = null;
            Boolean checker = false;
            for(int i = 0; i < numberOfItems; i++){
                do{
                    itemToCheck = getItem(iScanner);
                    if(i >= 1){
                        checker = checkIdenticalItems(itemToCheck, items);
                    }
                    if(checker){
                        System.out.println("You've entered identical items, please repeat input");
                    }
                }while(checker);
                items[i] = itemToCheck;
            }

            Factory tempFact = new Factory(name, address, items);
            return tempFact;
        }
        
        private static Store getStore(Scanner iScanner){
            System.out.println("Enter the name of the store");
            String name = iScanner.nextLine();
            System.out.println("Enter the address of the store");
            String address = iScanner.nextLine();
            System.out.println("Enter the number of items:");
            int numberOfItems = iScanner.nextInt();
            iScanner.nextLine();
            Item[] items = new Item[numberOfItems];
            Item itemToCheck = null;
            Boolean checker = false;
            for(int i = 0; i < numberOfItems; i++){
                do{
                    itemToCheck = getItem(iScanner);
                    if(i >= 1){
                        checker = checkIdenticalItems(itemToCheck, items);
                    }
                    if(checker){
                        System.out.println("You've entered identical items, please repeat input.");
                    }
                }while(checker);
                items[i] = itemToCheck;
            }

            Store tempStore = new Store(name, address, items);
            return tempStore;
        }

        private static BigDecimal calculateVolume(Item item) {
            BigDecimal volume = item.getHeight().multiply(item.getLength().multiply(item.getWidth()));
            return volume;
        }
        private static Factory getBiggestVolume(Factory[] factories){
            BigDecimal biggestVolume = calculateVolume(factories[0].getItems()[0]);
            Factory withBiggestVolume = factories[0];
            for(int i = 0; i < factories.length; i++){
                for(int j = 0; j < factories[i].getItems().length; j++){
                    BigDecimal tempVolume = calculateVolume(factories[i].getItems()[j]);
                    if(tempVolume.compareTo(biggestVolume) > 0){
                        biggestVolume = tempVolume;
                        withBiggestVolume = factories[i];
                    }
                }
            }
            return withBiggestVolume;
        }
        private static Store getStoreWithCheapestItem(Store[] stores){
            BigDecimal cheapestPrice = stores[0].getItems()[0].getSellingPrice();
            Store withCheapestPrice = stores[0];
            for(int i = 0; i < stores.length; i++) {
                for (int j = 0; j < stores[i].getItems().length; j++) {
                    BigDecimal tempPrice = stores[i].getItems()[j].getSellingPrice();
                    if (tempPrice.compareTo(cheapestPrice) < 0){
                        cheapestPrice = tempPrice;
                        withCheapestPrice = stores[i];
                    }

                }
            }
            return withCheapestPrice;
        }
    private static Boolean checkIdenticalCategories(Category categoryToCheck, Category[] categories){
        for(Category enteredCategory : categories){
            if(categoryToCheck.equals(enteredCategory))
                return true;
        }
        return false;
    }

    private static Boolean checkIdenticalItems(Item itemToCheck, Item[] items){
        for(Item enteredItem : items){
            if(itemToCheck.equals(enteredItem))
                return true;
        }
        return false;
    }
    private static Boolean checkIdenticalFactories(Factory factoryToCheck, Factory[] factories){
        for(Factory enteredFactory : factories){
            if(factoryToCheck.equals(enteredFactory))
                return true;
        }
        return false;
    }
    private static Boolean checkIdenticalStores(Store storeToCheck, Store[] stores){
        for(Store enteredStore : stores){
            if(storeToCheck.equals(enteredStore)){
                return true;
            }
        }
        return false;
    }

    private static Item getItemWithBiggestCal(Item[] items){
        Item itemWithBiggestCal = null;
        Integer mostCalories = null;
        for(Item item : items){
            if(item instanceof Meat && ((Meat) item).calculateCalories().compareTo(mostCalories.intValue()) > 0){
                mostCalories.equals(((Meat) item).calculateCalories());
                itemWithBiggestCal = item;
            }
            if(item instanceof Fruit && ((Fruit) item).calculateCalories().compareTo(mostCalories.intValue()) > 0){
                mostCalories.equals(((Fruit) item).calculateCalories());
                itemWithBiggestCal = item;
            }
        }
        return itemWithBiggestCal;
    }
    private static Item getItemWithBiggestPrice(Item[] items, Scanner iScanner){
        Item itemWithBiggestPrice = null;
        BigDecimal biggestPrice = null;
        for(Item item : items){
            System.out.println("Enter discount percentage");
            BigDecimal discountPercent = iScanner.nextBigDecimal();
            iScanner.nextLine();
            Discount discount = new Discount(discountPercent);
            BigDecimal hundred = new BigDecimal(100);
            BigDecimal discounted = discount.discountAmount().divide(hundred);
            if(item instanceof Meat && ((Meat) item).calculatePrice().subtract(discounted).compareTo(biggestPrice) > 0){
                biggestPrice.equals(((Meat) item).calculatePrice());
                itemWithBiggestPrice = item;
            }
            if(item instanceof Fruit && ((Fruit) item).calculatePrice().compareTo(biggestPrice) > 0){
                biggestPrice.equals(((Fruit) item).calculatePrice());
                itemWithBiggestPrice = item;
            }
        }
        return itemWithBiggestPrice;
    }
    private static void printBiggestPriceAndCalories(Item itemWithMostCalories, Item itemWithBiggestPrice){
        System.out.println("The item with the most calories is: " + itemWithMostCalories.getName());
        System.out.println();
        System.out.println("The item with the biggest price is: " + itemWithBiggestPrice);
    }
    private static void printShortestwarranty(Item[] items){
        Integer shortestWarranty = 1000;
        Item itemWithShortestWarranty = null;
        for(Item item : items){
            if(item instanceof Laptop && ((Laptop) item).warrantyDuration().compareTo(shortestWarranty) < 0){
                shortestWarranty.equals(((Laptop) item).warrantyDuration());
                itemWithShortestWarranty = item;
            }
        }
        System.out.println(itemWithShortestWarranty);
    }

}





