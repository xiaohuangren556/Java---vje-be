package hr.java.production.model;

import java.math.BigDecimal;
import java.util.Objects;

public class Meat extends Item implements Edible {
    BigDecimal weight;

    public BigDecimal getWeight() {
        return weight;
    }

    public void setWeight(BigDecimal weight) {
        this.weight = weight;
    }

    public Meat(String name, Category category, BigDecimal width, BigDecimal height, BigDecimal length, BigDecimal productionCost, BigDecimal sellingPrice, BigDecimal weight) {
        super(name, category, width, height, length, productionCost, sellingPrice);
        this.weight = weight;
    }

    @Override
    public Integer calculateCalories() {
       BigDecimal result =  weight.multiply(BigDecimal.valueOf(CALORIES_PER_KG));
       return result.intValue();
    }

    @Override
    public BigDecimal calculatePrice() {
        return weight.divide(getSellingPrice());
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        Meat meat = (Meat) o;
        return Objects.equals(weight, meat.weight);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), weight);
    }
}
