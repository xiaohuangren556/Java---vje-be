package hr.java.production.model;

public abstract class NamedEntity {
    private String name;
    public static final Integer ITEM_TYPE_MEAT = 1;
    public static final Integer ITEM_TYPE_FRUIT = 2;

    public static final String ITEM_TYPE_LAPTOP = "Y";

    public NamedEntity(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
