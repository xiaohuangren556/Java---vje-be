package hr.java.production.model;

import java.math.BigDecimal;
import java.time.LocalDate;

public non-sealed class Laptop extends Item implements Technical {

    Integer warrantyPeriod;
    public Laptop(String name, Category category, BigDecimal width, BigDecimal height, BigDecimal length, BigDecimal productionCost, BigDecimal sellingPrice, Integer warrantyPeriod) {
        super(name, category, width, height, length, productionCost, sellingPrice);
        warrantyPeriod = this.warrantyPeriod;
    }

    @Override
    public Integer warrantyDuration() {
        return warrantyPeriod;
    }

    @Override
    public String toString() {
        return "Laptop{" +
                "warrantyPeriod=" + warrantyPeriod +
                '}';
    }
}
