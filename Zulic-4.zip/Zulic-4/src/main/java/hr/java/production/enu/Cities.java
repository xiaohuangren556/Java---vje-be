package hr.java.production.enu;

public enum Cities {
    ZAGREB("Zagreb", "10000"), RIJEKA("Rijeka", "50000"), SPLIT("Split", "21000"), VARAZDIN("Varaždin", "40305");
    private String ime ,kod;

    Cities(String ime, String kod) {
        this.ime = ime;
        this.kod = kod;
    }

    public String getIme() {
        return ime;
    }

    public void setIme(String ime) {
        this.ime = ime;
    }

    public String getKod() {
        return kod;
    }

    public void setKod(String kod) {
        this.kod = kod;
    }
}
