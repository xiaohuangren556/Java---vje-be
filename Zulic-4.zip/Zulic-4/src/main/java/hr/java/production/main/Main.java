package hr.java.production.main;
import hr.java.production.enu.Cities;
import hr.java.production.sort.ProductionSorter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import hr.java.production.exception.ExceptionFactoryAndStore;
import hr.java.production.model.*;

import java.math.BigDecimal;
import java.util.*;

public class Main {
    private static final Logger logger = LoggerFactory.getLogger(Main.class);
    public static void main(String[] args) throws ExceptionFactoryAndStore {
            Scanner scanner = new Scanner(System.in);
            Category[] categories = new Category[3];
            Boolean checker = false;
            Category categoryToCompare = null;
            for(int i = 0; i < 3; i++){
                do{
                    categoryToCompare = getCategory(scanner);
                    if(i >= 1){
                        checker = checkIdenticalCategories(categoryToCompare, categories);
                    }
                    if(checker){
                        System.out.println("You've entered identical categories. Please, repeat input.");
                    }
                }while(checker);
                categories[i] = categoryToCompare;
            }

            checker = false;
            List<Item> items= new ArrayList<>(3);
            Item itemToCompare = null;

            for(int i = 0; i < 3; i++){
                do{
                    itemToCompare = getItem(scanner);
                    if(i >= 1){
                        checker = checkIdenticalItems(itemToCompare, items);
                    }
                    if(checker){
                        System.out.println("You've entered identical items. Please, repeat input.");
                    }
                }while(checker);

                items.add(itemToCompare);
            }
            Factory[] factories = new Factory[2];
            Factory factoryToCompare = null;
            for(int i = 0; i < 2; i++){
                if(i >= 1){
                    do{
                        try{
                            checker = false;
                            factoryToCompare = getFactory(scanner);
                            for(int j = 0; j < i; j++){
                                if(factories[j].equals(factoryToCompare)){
                                    throw new ExceptionFactoryAndStore("You have entered 2 identical factories!");
                                }
                            }
                        }
                        catch(ExceptionFactoryAndStore e){
                            String message = "You have to enter differing factories";
                            logger.error("Duplicate factory entered", e);
                            checker = true;
                        }


                    }while(checker);
                    factories[i] = getFactory(scanner);
                }
            }


            checker = false;
            Store[] stores = new Store[2];
            Store storeToCompare = null;
            for(int i = 0; i < 2; i++){
                do{
                    storeToCompare = getStore(scanner);
                    if(i >= 1){
                        checker = checkIdenticalStores(storeToCompare, stores);
                    }
                    if(checker){
                        System.out.println("You've entered identical stores. Please, repeat input.");
                    }
                }while(checker);
                stores[i] = storeToCompare;
            }

            Collections.sort(items, new ProductionSorter());
            Map<Category, List<Item>> categorizedItemsMap = new HashMap<>();
            for(Item item : items){
                categorizedItemsMap.get(item.getCategory()).add(item);
            }

            List<Item> listOfEdibleAndTechnical = new ArrayList<>();
            for(Item item : items){
                if(item instanceof Edible || item instanceof Technical){
                    listOfEdibleAndTechnical.add(item);
                }
            }
            Collections.sort(listOfEdibleAndTechnical, new ProductionSorter());
            Item mostExpensiveEdibleOrTechnical = listOfEdibleAndTechnical.getFirst();
            System.out.println("This is the most expensive edible or technical item " + mostExpensiveEdibleOrTechnical);
            Item leastExpensiveEdibleOrTechnical = listOfEdibleAndTechnical.getLast();
            System.out.println("This is the least expensive edible or technical item" + leastExpensiveEdibleOrTechnical);
        }

        private static Category getCategory(Scanner iscanner){
               System.out.println("Enter the name of the category");
               String name = iscanner.nextLine();
               System.out.println("Enter the description of the category");
               String description = iscanner.nextLine();
               Category novaKat = new Category(name, description);
               return novaKat;
        }

        private static Item getItem(Scanner iScanner){
            Item noviArt = null;
            System.out.println("Is the item edible? Input Yes or No");
            String isEdible = iScanner.nextLine();
            Integer typeOfEdible = null;
            BigDecimal weight = null;
            if(isEdible.equals("Yes")){
                System.out.println("Please choose if it's meat or fruit. 1 - meat, 2 - fruit");
                typeOfEdible = iScanner.nextInt();
                iScanner.nextLine();
                System.out.println("Please enter wight of item.");
                weight = iScanner.nextBigDecimal();
                iScanner.nextLine();
            }
            String isLaptop = null;
            if(isEdible.equals("No")){
                System.out.println("Is the item a laptop? Input Y or N");
                isLaptop = iScanner.nextLine();
            }
            System.out.println("Enter the name of the item");
            String name = iScanner.nextLine();
            System.out.println("Enter the category of the item");
            Category category = getCategory(iScanner);
            System.out.println("Enter the width of the item");
            BigDecimal width = iScanner.nextBigDecimal();
            iScanner.nextLine();
            System.out.println("Enter the height of the item");
            BigDecimal height = iScanner.nextBigDecimal();
            iScanner.nextLine();
            System.out.println("Enter the length of the item");
            BigDecimal length = iScanner.nextBigDecimal();
            iScanner.nextLine();
            System.out.println("Enter the production cost of the item");
            BigDecimal productionCost = iScanner.nextBigDecimal();
            iScanner.nextLine();
            System.out.println("Enter the selling price of the item");
            BigDecimal sellingPrice = iScanner.nextBigDecimal();
            iScanner.nextLine();
            if(typeOfEdible == Item.ITEM_TYPE_MEAT)
                noviArt = new Meat(name, category, width, height, length, productionCost, sellingPrice, weight);

            else if(typeOfEdible == Item.ITEM_TYPE_FRUIT)
                noviArt = new Fruit(name, category, width, height, length, productionCost, sellingPrice, weight);

            else if(isLaptop == Item.ITEM_TYPE_LAPTOP){
                System.out.println("Enter warranty period in months: ");
                Integer warrantyMonths = iScanner.nextInt();
                iScanner.nextLine();
                noviArt = new Laptop(name, category, width, height, length, productionCost, sellingPrice, warrantyMonths);
            }
            else
                noviArt = new Item(name, category, width, height, length, productionCost, sellingPrice);
            return noviArt;
        }

        private static Address getAddress(Scanner iScanner){
            System.out.println("Enter the name of the name of the street");
            String street = iScanner.nextLine();
            System.out.println("Enter the house number");
            String houseNumber = iScanner.nextLine();
            System.out.println("Enter the name of the city");
            String city = iScanner.nextLine();
            System.out.println("Enter the postal code of the city");
            String postalCode = iScanner.nextLine();
            Address tempAddress = new Address.Builder()
                    .street(street)
                    .houseNumber(houseNumber)
                    .city(Cities.valueOf(city))
                    .postalCode(Cities.valueOf(postalCode))
                    .build();
            return tempAddress;
        }
        private static Factory getFactory(Scanner iScanner){
            System.out.println("Enter the name of the factory");
            String name = iScanner.nextLine();
            System.out.println("Enter the address of the factory");
            Address address = getAddress(iScanner);
            System.out.println("Enter the number of items:");
            int numberOfItems = iScanner.nextInt();
            iScanner.nextLine();
            //Item[] items = new Item[numberOfItems];
            Set<Item> items = new HashSet<>(numberOfItems);
            Item itemToCheck = null;
            Boolean checker = false;
            for(int i = 0; i < numberOfItems; i++){
                do{
                    itemToCheck = getItem(iScanner);
                    if(i >= 1){
                        checker = checkIdenticalItemsinStoreAndFactory(itemToCheck, items);
                    }
                    if(checker){
                        System.out.println("You've entered identical items, please repeat input");
                    }
                }while(checker);
                items.add(itemToCheck);
            }
            Factory tempFact = new Factory(name, address, items);
            return tempFact;
        }
        
        private static Store getStore(Scanner iScanner){
            System.out.println("Enter the name of the store");
            String name = iScanner.nextLine();
            System.out.println("Enter the address of the store");
            String address = iScanner.nextLine();
            System.out.println("Enter the number of items:");
            int numberOfItems = iScanner.nextInt();
            iScanner.nextLine();
            Set<Item> items = new HashSet<>();
            Item itemToCheck = null;
            Boolean checker = false;
            for(int i = 0; i < numberOfItems; i++){
                do{
                    itemToCheck = getItem(iScanner);
                    if(i >= 1){
                        checker = checkIdenticalItemsinStoreAndFactory(itemToCheck, items);
                    }
                    if(checker){
                        System.out.println("You've entered identical items, please repeat input.");
                    }
                }while(checker);
                items.add(itemToCheck);
            }
            Store tempStore = new Store(name, address, items);
            return tempStore;
        }

        private static BigDecimal calculateVolume(Item item) {
            BigDecimal volume = item.getHeight().multiply(item.getLength().multiply(item.getWidth()));
            return volume;
        }
        

    private static Boolean checkIdenticalCategories(Category categoryToCheck, Category[] categories){
        for(Category enteredCategory : categories){
            if(categoryToCheck.equals(enteredCategory))
                return true;
        }
        return false;
    }

    private static Boolean checkIdenticalItems(Item itemToCheck, List<Item> items){
        for(Item enteredItem : items){
            if(itemToCheck.equals(enteredItem))
                return true;
        }
        return false;
    }
    private static Boolean checkIdenticalFactories(Factory factoryToCheck, Factory[] factories){
        for(Factory enteredFactory : factories){
            if(factoryToCheck.equals(enteredFactory))
                return true;
        }
        return false;
    }
    private static Boolean checkIdenticalStores(Store storeToCheck, Store[] stores){
        for(Store enteredStore : stores){
            if(storeToCheck.equals(enteredStore)){
                return true;
            }
        }
        return false;
    }

    private static Item getItemWithBiggestCal(Item[] items){
        Item itemWithBiggestCal = null;
        Integer mostCalories = null;
        Arrays.asList(items);
        for(Item item : items){
            if(item instanceof Meat && ((Meat) item).calculateCalories().compareTo(mostCalories.intValue()) > 0){
                mostCalories.equals(((Meat) item).calculateCalories());
                itemWithBiggestCal = item;
            }
            if(item instanceof Fruit && ((Fruit) item).calculateCalories().compareTo(mostCalories.intValue()) > 0){
                mostCalories.equals(((Fruit) item).calculateCalories());
                itemWithBiggestCal = item;
            }
        }
        return itemWithBiggestCal;
    }
    private static Item getItemWithBiggestPrice(Item[] items, Scanner iScanner){
        Item itemWithBiggestPrice = null;
        BigDecimal biggestPrice = null;
        Arrays.asList(items);
        for(Item item : items){
            System.out.println("Enter discount percentage");
            BigDecimal discountPercent = iScanner.nextBigDecimal();
            iScanner.nextLine();
            Discount discount = new Discount(discountPercent);
            BigDecimal hundred = new BigDecimal(100);
            BigDecimal discounted = discount.discountAmount().divide(hundred);
            if(item instanceof Meat && ((Meat) item).calculatePrice().subtract(discounted).compareTo(biggestPrice) > 0){
                biggestPrice.equals(((Meat) item).calculatePrice());
                itemWithBiggestPrice = item;
            }
            if(item instanceof Fruit && ((Fruit) item).calculatePrice().compareTo(biggestPrice) > 0){
                biggestPrice.equals(((Fruit) item).calculatePrice());
                itemWithBiggestPrice = item;
            }
        }
        return itemWithBiggestPrice;
    }
    private static void printBiggestPriceAndCalories(Item itemWithMostCalories, Item itemWithBiggestPrice){
        System.out.println("The item with the most calories is: " + itemWithMostCalories.getName());
        System.out.println();
        System.out.println("The item with the biggest price is: " + itemWithBiggestPrice);
    }
    private static void printShortestwarranty(Item[] items){
        Integer shortestWarranty = 1000;
        Item itemWithShortestWarranty = null;
        Arrays.asList(items);
        for(Item item : items){
            if(item instanceof Laptop && ((Laptop) item).warrantyDuration().compareTo(shortestWarranty) < 0){
                shortestWarranty.equals(((Laptop) item).warrantyDuration());
                itemWithShortestWarranty = item;
            }
        }
        System.out.println(itemWithShortestWarranty);
    }

    private static Boolean checkIdenticalItemsinStoreAndFactory(Item itemToCheck, Set<Item> items){
        for(Item enteredItem : items){
            if(itemToCheck.equals(enteredItem))
                return true;
        }
        return false;
    }

}





