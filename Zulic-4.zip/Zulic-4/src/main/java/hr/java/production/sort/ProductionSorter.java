package hr.java.production.sort;

import hr.java.production.model.Item;

import java.util.Comparator;

public class ProductionSorter implements Comparator<Item> {
    @Override
    public int compare(Item i1, Item i2) {
        return i2.getSellingPrice().compareTo(i1.getSellingPrice());
    }
}
