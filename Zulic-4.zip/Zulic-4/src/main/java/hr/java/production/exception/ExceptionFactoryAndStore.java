package hr.java.production.exception;

public class ExceptionFactoryAndStore extends Exception{

    public ExceptionFactoryAndStore(String message) {
        super(message);
    }

    public ExceptionFactoryAndStore(String message, Throwable cause) {
        super(message, cause);
    }

    public ExceptionFactoryAndStore(Throwable cause) {
        super(cause);
    }
}
