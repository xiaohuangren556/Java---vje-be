package hr.java.production.model;

import java.math.BigDecimal;

public interface Edible {
 int calculateCalories();
 BigDecimal calculatePrice();
}
