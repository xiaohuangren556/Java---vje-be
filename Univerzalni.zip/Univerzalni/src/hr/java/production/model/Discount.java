package hr.java.production.model;

public record Discount(int discountAmount) {
    public Discount {
    }
}
