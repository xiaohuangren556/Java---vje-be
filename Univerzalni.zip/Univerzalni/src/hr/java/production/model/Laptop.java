package hr.java.production.model;

import java.math.BigDecimal;

public non-sealed class Laptop extends Item implements Technical{

    int warrantyMonths;
    public Laptop(String name, Category category, BigDecimal width, BigDecimal height, BigDecimal length, BigDecimal productionCost, BigDecimal sellingPrice, int warrantyMonths) {
        super(name, category, width, height, length, productionCost, sellingPrice);
        this.warrantyMonths = warrantyMonths;
    }

    @Override
    public int warrantyPeriod() {return this.warrantyMonths;}
}
