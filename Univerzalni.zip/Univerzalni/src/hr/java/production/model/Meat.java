package hr.java.production.model;

import java.math.BigDecimal;

public class Meat extends Item implements Edible{
    public Meat(String name, Category category, BigDecimal width, BigDecimal height, BigDecimal length, BigDecimal productionCost, BigDecimal sellingPrice, BigDecimal weight) {
        super(name, category, width, height, length, productionCost, sellingPrice);
        this.weight = weight;
    }

    public BigDecimal getWeight() {
        return weight;
    }

    public void setWeight(BigDecimal weight) {
        this.weight = weight;
    }

    BigDecimal weight;
    public final int CONSTANT = 4;

    @Override
    public int calculateCalories() {
        BigDecimal result = weight.multiply(BigDecimal.valueOf(CONSTANT));
        return result.intValue();
    }

    @Override
    public BigDecimal calculatePrice() {
        return sellingPrice.multiply(weight);
    }
}
