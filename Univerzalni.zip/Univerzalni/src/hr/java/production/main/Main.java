package hr.java.production.main;

import hr.java.production.model.*;

import java.math.BigDecimal;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Category[] categories = enterCategories(scanner, 3);
        Item[] items = enterItems(scanner, 5);
        Factory[] factories = enterFactories(scanner, 2);
        Store[] stores = enterStores(scanner, 2);
    }
    public static Category[] enterCategories(Scanner s, int n){
        Category[] categories = new Category[n];
        for(int i = 0; i < n; i ++)
            categories[i] = enterSingularCategory(s);

        return categories;
    }
    public static Category enterSingularCategory(Scanner s){
        System.out.println("Enter name");
        String name = s.nextLine();
        System.out.println("Enter description");
        String desc = s.nextLine();
        return new Category(name, desc);
    }
    public static Item[] enterItems(Scanner s, int n){
        Item[] items = new Item[n];
        for(int i = 0; i < n; i++){
            System.out.println("Enter name:");
            String name = s.nextLine();
            System.out.println("Enter category:");
            System.out.println("If you want to select an edible, please enter Sweet or Meat as category name.");
            System.out.println("If you want to select a laptop, please enter laptop as category name.");
            Category category = enterSingularCategory(s);
            System.out.println("Enter width:");
            BigDecimal width = s.nextBigDecimal();
            System.out.println("Enter height");
            BigDecimal height = s.nextBigDecimal();
            System.out.println("Enter length:");
            BigDecimal length = s.nextBigDecimal();
            System.out.println("Enter production cost:");
            BigDecimal productionCost = s.nextBigDecimal();
            System.out.println("Enter selling price:");
            BigDecimal sellingPrice = s.nextBigDecimal();
            if(category.getName().equals("Sweet")){
                System.out.println("Enter weight");
                BigDecimal weight = s.nextBigDecimal();
                items[i] = new Sweets(name, category, width, height, length, productionCost, sellingPrice, weight);
            }
            else if(category.getName().equals("Meat")){
                System.out.println("Enter weight:");
                BigDecimal weight = s.nextBigDecimal();
                items[i] = new Meat(name, category, width, height, length, productionCost, sellingPrice, weight);
            }
            else if(category.getName().equals("Laptop")){
                System.out.println("Enter desired warranty period in months:");
                int warrantyMonths = s.nextInt();
                s.nextLine();
                items[i] = new Laptop(name, category, width, height, length, productionCost, sellingPrice, warrantyMonths);
            }
            else
                items[i] = new Item(name, category, width, height, length, productionCost, sellingPrice);
        }
        return items;
    }
    public static Factory enterSingularFactory(Scanner s){
        System.out.println("Enter name");
        String name = s.nextLine();
        Address address = enterSingularAddress(s);
        System.out.println("Enter number of items:");
        Integer noOfItems = s.nextInt();
        s.nextLine();
        Item[] items = enterItems(s, noOfItems);
        return new Factory(name, address, items);
    }

    public static Address enterSingularAddress(Scanner s){
        System.out.println("Enter street:");
        String street = s.nextLine();
        System.out.println("Enter house number:");
        String houseNumber = s.nextLine();
        System.out.println("Enter city:");
        String city = s.nextLine();
        System.out.println("Enter postal code:");
        String postalCode = s.nextLine();
        return new Address.Builder()
                .street(street)
                .houseNumber(houseNumber)
                .city(city)
                .postalCode(postalCode)
                .build();
    }
    public static Factory[] enterFactories(Scanner s, int n){
        Factory[] factories = new Factory[n];
        for(int i = 0; i < n; i++)
            factories[i] = enterSingularFactory(s);

        return factories;
    }

    public static Store enterSingularStore(Scanner s){
        System.out.println("Enter name");
        String name = s.nextLine();
        System.out.println("Enter web address");
        String webAddress = s.nextLine();
        System.out.println("Enter number of items:");
        Integer noOfItems = s.nextInt();
        s.nextLine();
        Item[] items = enterItems(s, noOfItems);
        return new Store(name, webAddress, items);
    }
    public static Store[] enterStores(Scanner s, int n){
        Store[] stores = new Store[n];
        for(int i = 0; i < n; i++)
            stores[i] = enterSingularStore(s);
        return stores;
    }


}
